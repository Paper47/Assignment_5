using Godot;
using System.Collections.Generic;

public partial class PhysicsDemo : Node2D
{
	[Export] public int ChainSegments = 5;
	[Export] public float SegmentDistance = 30f;
	[Export] public PackedScene SegmentScene; // set to res://ChainSegment.tscn in Inspector


	[Export] public float SpringStiffness = 150.0f; // higher = less stretch
	[Export] public float SpringDamping   = 6.0f;   // higher = more damped (less bobbing)


	[Export] public float ClickImpulse = 60.0f;

	private readonly List<RigidBody2D> _segments = new();
	private readonly List<Joint2D> _joints = new();

	// We’ll make a simple static anchor node at runtime
	private StaticBody2D _anchor;

	public override void _Ready()
	{
		if (SegmentScene == null)
		{
			GD.PushError("PhysicsDemo: SegmentScene is not assigned. Set it to ChainSegment.tscn.");
			return;
		}

		CreateChain();
	}

	private void CreateChain()
	{
		// 1) Create a static anchor where this Node2D is placed
		_anchor = new StaticBody2D { Name = "ChainAnchor" };
		AddChild(_anchor);
		_anchor.GlobalPosition = GlobalPosition; // top anchor at this node’s position

		// 2) Spawn RigidBody2D segments
		_segments.Clear();
		for (int i = 0; i < Mathf.Max(ChainSegments, 1); i++)
		{
			var seg = SegmentScene.Instantiate<RigidBody2D>();
			seg.LinearDamp = 4.0f;
			seg.AngularDamp = 6.0f;
			seg.Name = $"Segment_{i}";
			AddChild(seg);
			
			var pmat = new PhysicsMaterial { Friction = 0.8f, Bounce = 0.0f};
			seg.PhysicsMaterialOverride = pmat;

			// Position each segment vertically downward from the anchor
			var p = GlobalPosition + new Vector2(0, i * SegmentDistance);
			seg.GlobalPosition = p;

			// Optional: slightly reduce mass/inertia wobble by sleeping off start
			seg.CanSleep = true;

			_segments.Add(seg);

			// Add collision exceptions with the immediate previous neighbor
			if (i > 0)
			{
				seg.AddCollisionExceptionWith(_segments[i - 1]);
				_segments[i - 1].AddCollisionExceptionWith(seg);
			}
		}

		// 3) First joint: pin the first segment to the static anchor (non-stretchable pivot)
		if (_segments.Count > 0)
		{
			var pin = new PinJoint2D();
			AddChild(pin);
			pin.NodeA = _anchor.GetPath();         // anchor
			pin.NodeB = _segments[0].GetPath();    // first segment

			// Place the joint roughly between anchor and first segment for stability
			pin.GlobalPosition = (_anchor.GlobalPosition + _segments[0].GlobalPosition) * 0.5f;

			_joints.Add(pin);
		}

		// 4) Create spring joints between each pair of neighbors (stretchy rope feel)
		for (int i = 1; i < _segments.Count; i++)
		{
			var a = _segments[i - 1];
			var b = _segments[i];

			var pin = new PinJoint2D();
			AddChild(pin);

			pin.NodeA = a.GetPath();
			pin.NodeB = b.GetPath();

			// Put the joint roughly at the mid-point between the two segments
			pin.GlobalPosition = (a.GlobalPosition + b.GlobalPosition) * 0.5f;

			// Tune the spring
			a.AddCollisionExceptionWith(b);
			b.AddCollisionExceptionWith(a);

			_joints.Add(pin);
		}
	}

	/// <summary>
	/// Apply an impulse/force to a specific segment (e.g., from player interaction).
	/// Use a small time-step friendly impulse (instantaneous push).
	/// </summary>
	public void ApplyForceToSegment(int segmentIndex, Vector2 impulse)
	{
		if (segmentIndex < 0 || segmentIndex >= _segments.Count)
			return;

		var seg = _segments[segmentIndex];
		seg.ApplyImpulse(impulse);
	}

	// Optional: simple mouse interaction to test the chain.
	public override void _UnhandledInput(InputEvent @event)
	{
		if (@event is InputEventMouseButton mb && mb.Pressed && mb.ButtonIndex == MouseButton.Left)
		{
			var clickPos = GetGlobalMousePosition();

			// Find the nearest segment to the mouse click
			int nearest = -1;
			float bestDist2 = float.MaxValue;
			for (int i = 0; i < _segments.Count; i++)
			{
				float d2 = _segments[i].GlobalPosition.DistanceSquaredTo(clickPos);
				if (d2 < bestDist2)
				{
					bestDist2 = d2;
					nearest = i;
				}
			}

			if (nearest != -1)
			{
				// Impulse direction from segment toward click
				Vector2 dir = (clickPos - _segments[nearest].GlobalPosition).Normalized();
				ApplyForceToSegment(nearest, dir * ClickImpulse);
			}
		}
	}
}
