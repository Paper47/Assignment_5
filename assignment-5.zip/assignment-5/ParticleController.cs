using Godot;

public partial class ParticleController : GpuParticles2D
{
	private ShaderMaterial _shaderMaterial;
	private float _t;

	[Export] public string ShaderPath = "res://custom_particle.gdshader";
	[Export] public Texture2D ParticleTexture;

	[Export] public float WaveBase = 0.08f;
	[Export] public float WavePulse = 0.05f;
	[Export] public float WaveSpeed = 1.5f;

	public override void _Ready()
	{
		// --- Shader setup ---
		var shader = GD.Load<Shader>(ShaderPath);
		_shaderMaterial = new ShaderMaterial { Shader = shader };
		Material = _shaderMaterial;

		if (ParticleTexture != null)
			Texture = ParticleTexture;

		// --- Particle emitter setup ---
		Amount = 10;
		Lifetime = 2.5f;
		OneShot = false;
		Emitting = true;
		Preprocess = 0.5f;
		SpeedScale = 1.0f;

		// --- Process material (Godot 4.5: uses Min/Max properties) ---
		var pm = new ParticleProcessMaterial
		{
			Gravity = new Vector3(0, -20, 0),
			Direction = new Vector3(0, -1, 0),
			Spread = 40.0f,
		};

		// Velocity & damping ranges
		pm.InitialVelocityMin = 90.0f;
		pm.InitialVelocityMax = 90.0f;

		pm.DampingMin = 0.0f;
		pm.DampingMax = 0.0f;

		pm.AngularVelocityMin = 0.0f;
		pm.AngularVelocityMax = 0.0f;

		ProcessMaterial = pm;

		// --- Initial shader parameters ---
		_shaderMaterial.SetShaderParameter("wave_intensity", WaveBase);
		_shaderMaterial.SetShaderParameter("color_start", new Color(1.0f, 0.5f, 0.0f, 1.0f)); // orange
		_shaderMaterial.SetShaderParameter("color_end",   new Color(1.0f, 0.0f, 0.5f, 1.0f)); // magenta
	}

	public override void _Process(double delta)
	{
		_t += (float)delta;
		var wave = WaveBase + WavePulse * Mathf.Sin(_t * WaveSpeed);
		_shaderMaterial.SetShaderParameter("wave_intensity", wave);
	}
}
