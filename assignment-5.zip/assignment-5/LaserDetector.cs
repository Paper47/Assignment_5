using Godot;

public partial class LaserDetector : Node2D
{
	[Export] public float LaserLength = 500f;
	[Export] public Color LaserColorNormal = Colors.Green;
	[Export] public Color LaserColorAlert  = Colors.Red;
	[Export] public NodePath PlayerPath;

	// Optional tweaks
	[Export] public float AlarmHoldSeconds = 0.8f;
	[Export] public float AlertWidthMultiplier = 1.6f;

	private RayCast2D _rayCast;
	private Line2D _laserBeam;
	private Node2D _player;
	private bool _isAlarmActive = false;
	private Timer _alarmTimer;
	private Polygon2D _hitMarker; // little diamond at hit point
	private float _baseWidth = 2.0f;

	public override void _Ready()
	{
		SetupRaycast();
		SetupVisuals();

		if (PlayerPath != null && !PlayerPath.IsEmpty)
			_player = GetNodeOrNull<Node2D>(PlayerPath);

		// alarm timer (one-shot)
		_alarmTimer = new Timer
		{
			OneShot = true,
			WaitTime = AlarmHoldSeconds
		};
		AddChild(_alarmTimer);
		_alarmTimer.Timeout += ResetAlarm;
	}

	private void SetupRaycast()
	{
		_rayCast = new RayCast2D
		{
			Enabled = true,
			TargetPosition = Vector2.Right * LaserLength,
			CollideWithAreas = true,
			CollideWithBodies = true
		};
		AddChild(_rayCast);
		// (Optional) narrow the ray’s hit to specific layers:
		// _rayCast.CollisionMask = 1 << 0 | 1 << 1; // example
	}

	private void SetupVisuals()
	{
		// Line2D beam
		_laserBeam = new Line2D
		{
			Width = _baseWidth,
			DefaultColor = LaserColorNormal,
			Antialiased = true
		};
		AddChild(_laserBeam);
		_laserBeam.Points = new Vector2[] { Vector2.Zero, Vector2.Right * LaserLength };

		// Hit marker (small diamond)
		_hitMarker = new Polygon2D
		{
			Color = new Color(1f, 1f, 0.1f), // yellow
			Visible = false
		};
		// A tiny diamond centered at origin
		_hitMarker.Polygon = new Vector2[]
		{
			new Vector2( 0, -3),
			new Vector2( 3,  0),
			new Vector2( 0,  3),
			new Vector2(-3,  0)
		};
		AddChild(_hitMarker);
	}

	public override void _PhysicsProcess(double delta)
	{
		// Keep the ray length/direction aligned with this node’s rotation
		_rayCast.TargetPosition = Vector2.Right.Rotated(Rotation) * LaserLength;

		_rayCast.ForceRaycastUpdate();

		bool hit = _rayCast.IsColliding();
		Vector2 localEnd;

		if (hit)
		{
			Vector2 worldHit = _rayCast.GetCollisionPoint();
			localEnd = ToLocal(worldHit);

			// update hit marker
			_hitMarker.GlobalPosition = worldHit;
			_hitMarker.Visible = true;

			var collider = _rayCast.GetCollider();
			if (!_isAlarmActive && _player != null && collider == _player)
			{
				TriggerAlarm();
			}
		}
		else
		{
			localEnd = Vector2.Right * LaserLength;
			_hitMarker.Visible = false;
		}

		UpdateLaserBeam(localEnd);
	}

	private void UpdateLaserBeam(Vector2 localEnd)
	{
		// 0..end segment
		_laserBeam.Points = new Vector2[] { Vector2.Zero, localEnd };

		// Pulse thickness slightly while alarm is active
		if (_isAlarmActive)
			_laserBeam.Width = _baseWidth * AlertWidthMultiplier;
		else
			_laserBeam.Width = _baseWidth;
	}

	private void TriggerAlarm()
	{
		_isAlarmActive = true;
		_laserBeam.DefaultColor = LaserColorAlert;
		_alarmTimer.Start(); // will call ResetAlarm after AlarmHoldSeconds
		GD.Print("ALARM! Player detected!");
		// Optional: play a sound, flash a sprite, spawn particles, etc.
	}

	private void ResetAlarm()
	{
		_isAlarmActive = false;
		_laserBeam.DefaultColor = LaserColorNormal;
	}
}
